=======
Credits
=======

Development Lead
----------------

* Daniel Roy Greenfeld <pydanny@gmail.com>
* Audrey Roy Greenfeld (@audreyr)

Contributors
------------

* Tin Tvrtković <tinchester@gmail.com>
* @bcho <bcho@vtmer.com>
* George Sakkis (@gsakkis)
* Adam Williamson <awilliam AT redhat DOT com>
* Ionel Cristian Mărieș (@ionelmc)
* Malyshev Artem (@proofit404)
